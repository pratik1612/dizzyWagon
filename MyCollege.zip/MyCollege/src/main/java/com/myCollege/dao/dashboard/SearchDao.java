package com.myCollege.dao.dashboard;

import java.util.List;

import com.myCollege.actors.Address;
import com.myCollege.actors.Binding;
import com.myCollege.actors.Book;
import com.myCollege.actors.Category;
import com.myCollege.actors.Order;
import com.myCollege.exceptions.SearchException;

public interface SearchDao {

	public List<Book> searchBooks(String searchString) throws SearchException;

	public Book searchBook(Integer bookId);

	public List<Address> getAddressess(Integer userId);

	public void saveAddress(Address address);

	public Address getAddress(int addressId);

	public void saveOrder(Order order);

	public List<Binding> getAllBindings();

	public List<Category> getAllCategories();

	public List<Book> getBooksWithoutQuantities();
}
