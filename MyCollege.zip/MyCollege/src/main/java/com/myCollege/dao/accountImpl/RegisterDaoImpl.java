package com.myCollege.dao.accountImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.myCollege.actors.User;
import com.myCollege.dao.account.RegisterDao;

public class RegisterDaoImpl implements RegisterDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	public void registerUser(User user) {
		hibernateTemplate.saveOrUpdate(user);
	}

}
