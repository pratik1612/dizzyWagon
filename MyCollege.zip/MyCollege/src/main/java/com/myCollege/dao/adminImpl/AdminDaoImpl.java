package com.myCollege.dao.adminImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.myCollege.actors.Binding;
import com.myCollege.actors.Book;
import com.myCollege.actors.Category;
import com.myCollege.actors.Order;
import com.myCollege.form.BookForm;
import com.myCollege.service.dao.AdminDao;

public class AdminDaoImpl implements AdminDao{
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public void saveBooks(BookForm bookForm) {
		for(Book book : bookForm.getBooks()){
			hibernateTemplate.save(book);
		}
	}

	public boolean saveBinding(Binding binding) {
		hibernateTemplate.save(binding);
		return true;
	}

	public boolean saveCategory(Category category) {
		hibernateTemplate.save(category);
		return true;
	}

	public List<Order> getAllActiveOrders() {
		return hibernateTemplate.find("from Order where status='placed'");
	}

}
