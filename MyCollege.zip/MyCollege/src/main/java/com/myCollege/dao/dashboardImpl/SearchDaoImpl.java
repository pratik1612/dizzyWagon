package com.myCollege.dao.dashboardImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.myCollege.actors.Address;
import com.myCollege.actors.Binding;
import com.myCollege.actors.Book;
import com.myCollege.actors.Category;
import com.myCollege.actors.Order;
import com.myCollege.dao.dashboard.SearchDao;
import com.myCollege.exceptions.SearchException;

@Transactional
public class SearchDaoImpl implements SearchDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	public List<Book> searchBooks(String searchString) throws SearchException {
		List<Book> books = new ArrayList<Book>();
		try {
			SessionFactory factory = hibernateTemplate.getSessionFactory();
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(Book.class,"book");
			Disjunction disCriteria = Restrictions.disjunction();
			// search
			// 1. check whole string
			disCriteria.add(Restrictions.like("title", searchString,
					MatchMode.ANYWHERE));
			disCriteria.add(Restrictions.like("author", searchString,
					MatchMode.ANYWHERE));
			disCriteria.add(Restrictions.like("publication", searchString,
					MatchMode.ANYWHERE));
			
			criteria.add(disCriteria);
			books = criteria.list();
			session.flush();
			tx.commit();
			session.close();
			
		} catch (Exception e) {
			throw new SearchException();
		}
		
		
		
		return books;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public Book searchBook(Integer bookId) {
		Book book = hibernateTemplate.get(Book.class, bookId);
		return book;
	}

	public List<Address> getAddressess(Integer userId) {
		List<Address> addresses = hibernateTemplate
				.find("from Address where user.userId=" + userId);
		return addresses;
	}

	public void saveAddress(Address address) {
		hibernateTemplate.save(address);
	}

	public Address getAddress(int addressId) {
		return hibernateTemplate.get(Address.class, addressId);
	}

	public void saveOrder(Order order) {
		hibernateTemplate.save(order);
	}

	public List<Binding> getAllBindings() {
		return hibernateTemplate.find("from Binding");
	}

	public List<Book> getBooksWithoutQuantities() {
		return null;
	}

	public List<Category> getAllCategories() {
		return hibernateTemplate.find("from Category");
	}

}
