package com.myCollege.dao.account;

import com.myCollege.actors.User;

public interface RegisterDao {

	public void registerUser(User user);
}
