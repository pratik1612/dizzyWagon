package com.myCollege.dao.account;

import com.myCollege.actors.User;

public interface LoginDao {

	public boolean validateUsername(String username, String password);

	public User getUser(String email);

	public boolean isAdmin(long phone);

	public boolean isAdmin(String email);
}
