package com.myCollege.dao.accountImpl;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.myCollege.actors.User;
import com.myCollege.dao.account.LoginDao;

public class LoginDaoImpl implements LoginDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public boolean validateUsername(String login, String password) {
		SessionFactory factory = null;
		Session session = null;
		Transaction  tx = null;
		Criteria criteria;
		boolean validate = false;
		try {
			factory = hibernateTemplate.getSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();
			criteria = session.createCriteria(User.class);
			
			Criterion email= Restrictions.and(Restrictions.eq("email", login),Restrictions.eq("password", password));
			Criterion phone= Restrictions.and(Restrictions.eq("phoneNumber", login),Restrictions.eq("password", password));
			
			criteria.add(Restrictions.or(email, phone));
			
			criteria.setProjection(Projections.rowCount());
			
			if (criteria.list().size() != 0) {
				validate = true;
				return validate;
			} else {
				return validate;
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}finally{
			tx.commit();
			session.flush();
		}
		return validate;
	}

	public User getUser(String userName) {
		SessionFactory factory = null;
		Session session = null;
		Transaction  tx = null;
		Criteria criteria = null;
		
		try {
			factory = hibernateTemplate.getSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();
			criteria = session.createCriteria(User.class);
			
			Disjunction disCriteria = Restrictions.disjunction();
			disCriteria.add(Restrictions.eq("email", userName));
			disCriteria.add(Restrictions.eq("phoneNumber", userName));
			
			criteria.add(disCriteria);
		} catch (HibernateException e) {
			e.printStackTrace();
		}finally{
			tx.commit();
			session.flush();
		}
		return (User)criteria.uniqueResult();
	}

	public boolean isAdmin(long phone) {
		
		SessionFactory factory = null;
		Session session = null;
		Transaction  tx = null;
		Criteria criteria;
		boolean validate = false;
		try {
			factory = hibernateTemplate.getSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();
			criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("phone", phone)).add(
					Restrictions.eq("isAdmin", 1));
			criteria.setProjection(Projections.rowCount());
			if ((Long) criteria.uniqueResult() != 0) {
				validate = true;
				return validate;
			} else {
				return validate;
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}finally{
			tx.commit();
			session.flush();
		}
		return validate;
	}

	public boolean isAdmin(String email) {
		SessionFactory factory = null;
		Session session = null;
		Transaction  tx = null;
		Criteria criteria;
		boolean validate = false;
		try {
			factory = hibernateTemplate.getSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();
			criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("email", email)).add(
					Restrictions.eq("isAdmin", 1));
			criteria.setProjection(Projections.rowCount());
			if ((Long) criteria.uniqueResult() != 0) {
				validate = true;
				return validate;
			} else {
				return validate;
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}finally{
			tx.commit();
			session.flush();
		}
		return validate;
	}
}
