package com.myCollege.form;

import java.util.List;

import com.myCollege.actors.Book;

public class BookForm {

	private List<Book> books;

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}
	
	public BookForm() {
	}
}
