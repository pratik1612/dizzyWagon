package com.myCollege.actors;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

@Entity
@Table(name="books")
public class Book implements Serializable{

	@Id
	@Column(name="book_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer bookId;
	
	@Column(name="book_title",nullable = false)
	private String title;
	
	@Column(name="year")
	/*@Temporal(TemporalType.DATE)*/
	private int year;
	
	@Column(name="ISBN",unique=true,nullable = false)
	private String ISBN;
	
	@Column(name="author")
	private String author;
	
	@Column(name="publication")
	private String publication;
	
	@ManyToMany(cascade = CascadeType.MERGE)
	@JoinTable(name = "book_category", joinColumns = {
			@JoinColumn(name = "book_id") },
			inverseJoinColumns = { @JoinColumn(name = "category_id") })
	private List<Category> categories = new ArrayList<Category>();

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	@OneToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="binding_id")
	private Binding binding;
	
	@Column(name="pages")
	private int pages;
	
	@Column(name="price")
	private double price;
	
	public Binding getBinding() {
		return binding;
	}

	public void setBinding(Binding binding) {
		this.binding = binding;
	}

	public int getPages() {
		return pages;
	}

	public void setPages(int pages) {
		this.pages = pages;
	}

	
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getPublication() {
		return publication;
	}

	public void setPublication(String publication) {
		this.publication = publication;
	}


	public Book() {
		// TODO Auto-generated constructor stub
	}

	public Book(Integer bookId, String title, int year, String iSBN,
			String author, String publication,
			Binding binding, int pages, int price) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.year = year;
		ISBN = iSBN;
		this.author = author;
		this.publication = publication;
		this.binding = binding;
		this.pages = pages;
		this.price = price;
	}
	
	
}
