package com.myCollege.actors;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="quantity")
public class Quantity implements Serializable{
	
	@Id
	@GeneratedValue
	@Column(name="id")
	private Integer quantityId;
	
	@Column(name="book_title")
	private String bookTitle;
	
	@Column(name="author")
	private String author;
	
	@Column(name="quantity")
	private int quantity;

	public Integer getQuantityId() {
		return quantityId;
	}

	public void setQuantityId(Integer quantityId) {
		this.quantityId = quantityId;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	

}
