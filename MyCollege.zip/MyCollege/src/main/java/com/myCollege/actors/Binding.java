package com.myCollege.actors;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="binding")
public class Binding implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="binding_id")
	private Integer bindingId;
	
	@Column(name="type_of_binding")
	private String bindingType;
	
	public Integer getBindingId() {
		return bindingId;
	}

	public void setBindingId(Integer bindingId) {
		this.bindingId = bindingId;
	}

	public String getBindingType() {
		return bindingType;
	}

	public void setBindingType(String bindingType) {
		this.bindingType = bindingType;
	}
	
	public Binding() {
		// TODO Auto-generated constructor stub
	}

	public Binding(Integer bindingId, String bindingType) {
		super();
		this.bindingId = bindingId;
		this.bindingType = bindingType;
	}
	
	

}
