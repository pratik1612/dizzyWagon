package com.myCollege.actors;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class BookSession {
	
	private User user;
	private Order order;
	private Map<Book,Integer> cart;

	public BookSession() {
		user = new User();
		order = new Order();
		cart = new HashMap<Book, Integer>();
	}
	
	public BookSession(Map<Book,Integer> cart) {
		this.cart = cart;
	}

	public BookSession(User user, Order order) {
		super();
		this.user = user;
		this.order = order;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Map<Book,Integer> getCart() {
		return cart;
	}

	public void setCart(Map<Book,Integer> cart) {
		this.cart = cart;
	}
}
