package com.myCollege.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.myCollege.actors.User;

public class UserValidator implements Validator {

	public boolean supports(Class<?> arg0) {
		return false;
	}

	public void validate(Object obj, Errors err) {
		User user = null;
		if (obj instanceof User) {
			user = (User) obj;
		}

		if (user != null) {
			if (user.getFirstname().isEmpty()) {
				err.rejectValue("firstname", "error.empty.user.firstname",
						"empty");
			}
			if (user.getLastName().isEmpty()) {
				err.rejectValue("lastName", "error.empty.user.lastname",
						"empty");
			}
			if (user.getEmail().isEmpty()) {
				err.rejectValue("email", "error.empty.user.email",
						"empty");
			}
			if (user.getCurrentCity().isEmpty()) {
				err.rejectValue("currentCity", "error.empty.user.currentCity",
						"empty");
			}
			if (user.getPassword().isEmpty()) {
				err.rejectValue("password", "error.empty.user.password",
						"empty");
			}
			
			ValidationUtils.rejectIfEmptyOrWhitespace(err, "phoneNumber",
					"error.phoneNumber.required", "Please enter a Phone Number");

		}
	}

}