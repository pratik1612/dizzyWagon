package com.myCollege.controllers.dashboardControllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.myCollege.actors.Book;
import com.myCollege.actors.BookSession;
import com.myCollege.exceptions.SearchException;
import com.myCollege.service.dashboard.SearchService;

@Controller
@SessionAttributes("bookSession")
public class DashboardController {

	@Autowired
	private SearchService searchService;

	@RequestMapping("/dashboard.do")
	public ModelAndView dashboard(HttpSession session) {
		BookSession bookSession = (BookSession) session
				.getAttribute("bookSession");

		if (bookSession == null) {
			bookSession = new BookSession();
		}
		session.setAttribute("bookSession", bookSession);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("dashboard");
		return mav;
	}

	@RequestMapping(value = "/search.do", method = RequestMethod.POST)
	public ModelAndView search(@RequestParam("search") String search) {
		ModelAndView mav = new ModelAndView();
		List<Book> books = new ArrayList<Book>();
		try {
			books = searchService.searchBooks(search);
			mav.addObject("books", books);
			mav.addObject("search", search);
			mav.setViewName("productView");
		} catch (SearchException e) {
			e.printStackTrace();
			mav.setViewName("error");
		}

		return mav;
	}
}
