package com.myCollege.controllers.orderControllers;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.myCollege.actors.Address;
import com.myCollege.actors.Book;
import com.myCollege.actors.BookSession;
import com.myCollege.actors.Order;
import com.myCollege.actors.User;
import com.myCollege.service.dashboard.SearchService;

@Controller
@SessionAttributes("bookSession")
public class OrderController {

	@Autowired
	private SearchService searchService;

	@RequestMapping(value = "/buyNow/{id}")
	public ModelAndView buyNow(@PathVariable(value = "id") int bookId,
			HttpSession session, @RequestParam("quantity") int quantity) {
		ModelAndView mav = new ModelAndView();
		Book book = searchService.searchBook(bookId);
		Order order = new Order();
		order.setBook(book);
		order.setQuantity(quantity);

		BookSession bookSession = (BookSession) session
				.getAttribute("bookSession");
		
		bookSession.setOrder(order);
		bookSession.getCart().put(book, 1);
		
		mav.addObject("bookSession", bookSession);
		mav.addObject("newUser", new User());
		
		if(bookSession.getUser().getUserId() == null){
			mav.addObject("buy", "buyNow");
			mav.setViewName("login");
		}else{
			mav.setViewName("orderPage");
		}
					
		return mav;
	}

	@RequestMapping(value = "/orderNow")
	public ModelAndView orderNow(
			@ModelAttribute("bookSession") BookSession bookSession,
			@RequestParam("quantity") int quantity) {
		ModelAndView mav = new ModelAndView();
		bookSession.getOrder().setQuantity(quantity);
		List<Address> addresses = searchService.getAddressess(bookSession
				.getUser().getUserId());
		if (addresses.isEmpty()) {
			mav = addNewAddress();
		} else {
			mav.addObject("bookSession", bookSession);
			mav.addObject("addressess", addresses);
			mav.setViewName("showAddress");
		}
		return mav;
	}

	@RequestMapping(value = "/addAddress", method = RequestMethod.POST)
	public ModelAndView addAddress(
			@ModelAttribute("bookSession") BookSession bookSession,
			@ModelAttribute("address") Address address) {
		ModelAndView mav = new ModelAndView();
		address.setUser(bookSession.getUser());
		searchService.saveAddress(address);
		List<Address> addresses = searchService.getAddressess(bookSession
				.getUser().getUserId());
		mav.addObject("addressess", addresses);
		mav.setViewName("showAddress");
		return mav;
	}

	@RequestMapping(value = "/placeOrder", method = RequestMethod.POST)
	public ModelAndView placeOrder(@RequestParam("address") int addressId,
		@ModelAttribute("bookSession") BookSession bookSession,HttpSession session) {
		ModelAndView mav = new ModelAndView();
		try{
			Order order = bookSession.getOrder();
			if(order != null){
				Address address = searchService.getAddress(addressId);
				bookSession.getOrder().setOrderStatus("Placed");
				bookSession.getOrder().setAddress(address);
				bookSession.getOrder().setUser(bookSession.getUser());
				searchService.saveOrder(bookSession.getOrder());
			}else{
				Iterator<Entry<Book, Integer>> bookIterator  = bookSession.getCart().entrySet().iterator();
				while(bookIterator.hasNext()){
					Entry<Book, Integer> bookEntry = bookIterator.next();
					Address address = searchService.getAddress(addressId);
					Order cartOrder = new Order();
					cartOrder.setAddress(address);
					cartOrder.setOrderStatus("placed");
					cartOrder.setUser(bookSession.getUser());
					cartOrder.setBook(bookEntry.getKey());
					cartOrder.setQuantity(bookEntry.getValue());
					searchService.saveOrder(cartOrder);
				}
			}
		}catch(Exception e){
			Iterator<Entry<Book, Integer>> bookIterator  = bookSession.getCart().entrySet().iterator();
			while(bookIterator.hasNext()){
				Entry<Book, Integer> bookEntry = bookIterator.next();
				Address address = searchService.getAddress(addressId);
				Order cartOrder = new Order();
				cartOrder.setAddress(address);
				cartOrder.setOrderStatus("placed");
				cartOrder.setUser(bookSession.getUser());
				cartOrder.setBook(bookEntry.getKey());
				cartOrder.setQuantity(bookEntry.getValue());
				searchService.saveOrder(cartOrder);
			}
		}
		bookSession.setCart(new HashMap<Book, Integer>());
		session.setAttribute("bookSession", bookSession);
		mav.setViewName("success");
		return mav;
	}

	public ModelAndView addNewAddress() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("address", new Address());
		mav.setViewName("addAddress");
		return mav;
	}

	@RequestMapping("/addNewAddress")
	public ModelAndView addAnotherAddress(
			@ModelAttribute("bookSession") BookSession bookSession) {
		ModelAndView mav = new ModelAndView();
		mav = addNewAddress();
		return mav;
	}
}
