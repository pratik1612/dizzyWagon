package com.myCollege.controllers.orderControllers;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import javax.servlet.http.HttpSession;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.myCollege.actors.Address;
import com.myCollege.actors.Book;
import com.myCollege.actors.BookSession;
import com.myCollege.actors.User;
import com.myCollege.service.dashboard.SearchService;

@Controller
@SessionAttributes("bookSession")
public class CartController {

	
	@Autowired
	private SearchService searchService;
	
	OrderController controller = new OrderController();
	
	@RequestMapping(value="/addToCart/{id}/{search}/{quantity}")
	public @ResponseBody BookSession addToCart(HttpSession httpSession,@PathVariable("id") int bookId,@PathVariable("search")String search,@PathVariable("quantity") int quantity) throws JsonGenerationException, JsonMappingException, IOException{
		BookSession bookSession = (BookSession) httpSession.getAttribute("bookSession"); 
		
			bookSession.getCart().put(searchService.searchBook(bookId),1);
			httpSession.setAttribute("bookSession", bookSession);
			
		return bookSession;
	}
	
	@RequestMapping("/removeFromCart/{id}/{search}")
	public @ResponseBody BookSession removeFromCart(HttpSession httpSession,@PathVariable("id") int bookId,@PathVariable("search")String search){
		
		BookSession bookSession = (BookSession) httpSession.getAttribute("bookSession");
		
		Iterator<Entry<Book, Integer>> bookIterator  = bookSession.getCart().entrySet().iterator();
		while(bookIterator.hasNext()){
			if(bookIterator.next().getKey().getBookId()==bookId){
				bookIterator.remove();
			}
		}
		httpSession.setAttribute("bookSession", bookSession);
		return bookSession;
	}
	
	@RequestMapping("/cartView")
	public ModelAndView viewCart(HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		BookSession bookSession = (BookSession) httpSession.getAttribute("bookSession");
		mav.addObject("bookSession", bookSession);
		mav.setViewName("cartView");
		return mav;
	}
	
	@RequestMapping("/checkOut")
	public ModelAndView checkOut(HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		BookSession bookSession = (BookSession) httpSession.getAttribute("bookSession");
				User user = (User) bookSession.getUser();
				if (user.getUserId() != null) {
					mav.addObject("bookSession", bookSession);
					List<Address> addresses = searchService.getAddressess(bookSession
							.getUser().getUserId());
					if (addresses.isEmpty()) {
						mav = controller.addNewAddress();
					} else {
						mav.addObject("bookSession", bookSession);
						mav.addObject("addressess", addresses);
						mav.setViewName("showAddress");
					}
				}else{
					mav.addObject("bookSession", bookSession);
					mav.addObject("newUser", new User());
					mav.addObject("buy", "cart");
					mav.setViewName("login");
				}
		return mav;
	}
	
	@RequestMapping("/increaseCart/{bookId}")
	public @ResponseBody BookSession increaseCart(HttpSession httpSession,@PathVariable("bookId") int bookId){
		BookSession bookSession = (BookSession) httpSession.getAttribute("bookSession");
		Iterator<Entry<Book, Integer>> bookIterator  = bookSession.getCart().entrySet().iterator();
		while(bookIterator.hasNext()){
			Entry<Book, Integer> thisBook = bookIterator.next();
			if(thisBook.getKey().getBookId()==bookId){
				int value = thisBook.getValue();
				thisBook.setValue(value*1+1);
			}
		}
		httpSession.setAttribute("bookSession", bookSession);
		return bookSession;
	}
	
	@RequestMapping("/decreaseCart/{bookId}")
	public @ResponseBody BookSession decreaseCart(HttpSession httpSession,@PathVariable("bookId") int bookId){
		BookSession bookSession = (BookSession) httpSession.getAttribute("bookSession");
		Iterator<Entry<Book, Integer>> bookIterator  = bookSession.getCart().entrySet().iterator();
		while(bookIterator.hasNext()){
			Entry<Book, Integer> thisBook = bookIterator.next();
			if(thisBook.getKey().getBookId()==bookId){
				int value = thisBook.getValue();
				thisBook.setValue(value*1-1);
			}
		}
		httpSession.setAttribute("bookSession", bookSession);
		return bookSession;
	}
	
	@RequestMapping("/removeFromCart/{bookId}")
	public @ResponseBody BookSession removeFromCart(HttpSession httpSession,@PathVariable("bookId") int bookId){
		BookSession bookSession = (BookSession) httpSession.getAttribute("bookSession");
		Iterator<Entry<Book, Integer>> bookIterator  = bookSession.getCart().entrySet().iterator();
		while(bookIterator.hasNext()){
			Entry<Book, Integer> thisBook = bookIterator.next();
			if(thisBook.getKey().getBookId()==bookId){
				bookIterator.remove();
			}
		}
		httpSession.setAttribute("bookSession", bookSession);
		return bookSession;
	}
}
