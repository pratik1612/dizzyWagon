package com.myCollege.controllers.accountControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.myCollege.actors.Binding;
import com.myCollege.actors.Category;
import com.myCollege.actors.Order;
import com.myCollege.form.BookForm;
import com.myCollege.service.admin.AdminService;
import com.myCollege.service.dashboard.SearchService;


@Controller
public class AdminController {

	@Autowired
	private SearchService searchService;
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping("/addBooks")
	public ModelAndView addBooks(){
		ModelAndView mav = new ModelAndView();
		List<Binding> bindings = searchService.getAllBindings();
		List<Category> categories = searchService.getAllCategories();
		BookForm bookForm = new BookForm();		
		mav.addObject("bookForm", bookForm);
		mav.addObject("bindings", bindings);
		mav.addObject("categories", categories);
		mav.setViewName("addBooks");
		return mav;
	}
	
	@RequestMapping("/adminHomePage")
	public ModelAndView adminHome(){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("adminHomePage");
		return mav;
	}
	
	
	@RequestMapping(value="/addBooks",method=RequestMethod.POST)
	public ModelAndView addBooks(@ModelAttribute("bookForm")BookForm bookForm){
		ModelAndView mav = new ModelAndView();
		List<Binding> bindings = searchService.getAllBindings();
		adminService.saveBooks(bookForm);
		List<Category> categories = searchService.getAllCategories();
		BookForm newBookForm = new BookForm();		
		
		mav.addObject("bookForm", newBookForm);
		mav.addObject("bindings", bindings);
		mav.addObject("categories", categories);	
		return mav;
	}
	
 
	@RequestMapping(value="/addBinding",method=RequestMethod.GET)
	public ModelAndView saveBinding(@RequestParam("binding") String bindingType){
		
		Binding binding = new Binding();
		binding.setBindingType(bindingType);
		adminService.saveBinding(binding);
		ModelAndView mav = new ModelAndView();
		List<Binding> bindings = searchService.getAllBindings();
		List<Category> categories = searchService.getAllCategories();
		BookForm bookForm = new BookForm();		
		
		mav.addObject("bookForm", bookForm);
		mav.addObject("bindings", bindings);
		mav.addObject("categories", categories);
		mav.setViewName("addBooks");
		return mav;
	}
	
	@RequestMapping(value="/addCategory",method=RequestMethod.GET)
	public ModelAndView saveCategory(@RequestParam("category") String categoryName){
		Category category = new Category();
		category.setCategoryName(categoryName);
		adminService.saveCategory(category);
		ModelAndView mav = new ModelAndView();
		List<Binding> bindings = searchService.getAllBindings();
		List<Category> categories = searchService.getAllCategories();
		BookForm bookForm = new BookForm();		
		
		mav.addObject("bookForm", bookForm);
		mav.addObject("bindings", bindings);
		mav.addObject("categories", categories);
		mav.setViewName("addBooks");
		return mav;
	}
	
	@RequestMapping(value="/addOffers")
	public ModelAndView addOffer(){
		ModelAndView mav = new ModelAndView();
		
		return mav;
	}
	
	
	@RequestMapping("/showOrders")
	public ModelAndView showOrders(){
		ModelAndView mav = new ModelAndView();
		List<Order> activeOrders = adminService.getAllActiveOrders();
		mav.setViewName("orders");
		mav.addObject("orders", activeOrders);
		return mav;
	}
	
}
