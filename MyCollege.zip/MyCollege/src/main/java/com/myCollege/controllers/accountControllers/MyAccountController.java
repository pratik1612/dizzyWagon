package com.myCollege.controllers.accountControllers;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.ModelAndView;

import com.myCollege.actors.Address;
import com.myCollege.actors.BookSession;
import com.myCollege.actors.User;
import com.myCollege.controllers.orderControllers.OrderController;
import com.myCollege.service.account.LoginService;
import com.myCollege.service.account.RegisterService;
import com.myCollege.service.dashboard.SearchService;
import com.myCollege.validators.UserValidator;

@Controller
@SessionAttributes("bookSession")
public class MyAccountController implements ServletContextAware{

	@Autowired
	private RegisterService userService;
	
	@Autowired
	ServletContext context;

	@Autowired
	private LoginService loginService;

	@Autowired
	private UserValidator userValidator;
	
	@Autowired
	private SearchService searchService;
	
	OrderController controller = new OrderController();
	
	@RequestMapping("/myAccount.do")
	public ModelAndView login(HttpSession session) {
		ModelAndView mav = new ModelAndView();
			
			mav.addObject("buy","login");
			mav.addObject("newUser", new User());
			mav.setViewName("login");
			
		return mav;
	}

	@RequestMapping(value = "/login.do", method = RequestMethod.POST)
	public ModelAndView login(@RequestParam("userName") String username,
			@RequestParam("loginPassword") String password,
			@RequestParam(value="buy",required=false) String buy,HttpSession session) {
		ModelAndView mav = new ModelAndView();
		BookSession bookSession = (BookSession)session.getAttribute("bookSession");
			if (loginService.validateUsername(username, password)) {
				User loggedUser = loginService.getUser(username);
				bookSession.setUser(loggedUser);
				mav.addObject("bookSession",bookSession);
				if (buy.equalsIgnoreCase("buyNow")) {
					mav.addObject("order", bookSession.getOrder());
					mav.setViewName("orderPage");
				} else if (buy.equalsIgnoreCase("cart")) {
					mav.setViewName("cartPage");
				} else if(buy.equalsIgnoreCase("login")){
					mav.setViewName("dashboard");
				}else{
					mav.setViewName("error");
				}
			} else {
				mav.setViewName("login");
				mav.addObject("newUser", new User());
				mav.addObject("invalidUser",
						"Either username or password is incorrect");
			}

		return mav;

	}

	@RequestMapping("/editAccount.do")
	public ModelAndView editUser(@ModelAttribute("bookSession") BookSession bookSession) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("newUser", bookSession.getUser());
		mav.setViewName("login");
		return mav;

	}

	@RequestMapping(value = "/register.do", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("newUser") User user,
			BindingResult errors) {
		ModelAndView mav = new ModelAndView();
		userValidator.validate(user, errors);

		if (errors.hasErrors()) {
			mav.addObject("buy","login");
			mav.addObject("newUser", new User());
			
		} else {
			userService.registerUser(user);
		}
		mav.setViewName("login");
		return mav;
	}

	@RequestMapping("/logout.do")
	public ModelAndView logoutUser(HttpSession session,HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		BookSession bookSession = (BookSession)session.getAttribute("bookSession");
		bookSession.setUser(new User());
		mav.addObject("bookSession", bookSession);
		mav.setViewName("dashboard");
		return mav;
	}

	public void setServletContext(ServletContext servletContext) {
		this.context = servletContext;
		
	}
}
