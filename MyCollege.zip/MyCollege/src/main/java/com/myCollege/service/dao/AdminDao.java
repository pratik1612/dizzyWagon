package com.myCollege.service.dao;

import java.util.List;

import com.myCollege.actors.Binding;
import com.myCollege.actors.Category;
import com.myCollege.actors.Order;
import com.myCollege.form.BookForm;

public interface AdminDao {

	public void saveBooks(BookForm bookForm);

	public boolean saveBinding(Binding binding);

	public boolean saveCategory(Category category);

	public List<Order> getAllActiveOrders();
}
