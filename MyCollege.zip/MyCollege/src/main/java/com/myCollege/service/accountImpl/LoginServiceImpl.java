package com.myCollege.service.accountImpl;

import org.springframework.beans.factory.annotation.Autowired;

import com.myCollege.actors.User;
import com.myCollege.dao.account.LoginDao;
import com.myCollege.service.account.LoginService;

public class LoginServiceImpl implements LoginService{

	@Autowired
	private LoginDao loginDao;
	
	public boolean validateUsername(String username, String password) {
		return loginDao.validateUsername(username, password);
	}


	public User getUser(String email) {
		return loginDao.getUser(email);
	}

	public boolean isAdmin(long phone) {
		return loginDao.isAdmin(phone);
	}

	public boolean isAdmin(String email) {
		return loginDao.isAdmin(email);
	}

}
