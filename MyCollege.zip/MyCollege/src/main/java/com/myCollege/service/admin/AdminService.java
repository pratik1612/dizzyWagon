package com.myCollege.service.admin;

import java.util.List;

import com.myCollege.actors.Binding;
import com.myCollege.actors.Category;
import com.myCollege.actors.Order;
import com.myCollege.form.BookForm;

public interface AdminService {
	
	public void saveBooks(BookForm bookForm);

	public boolean saveBinding(Binding binding);

	public boolean saveCategory(Category category);

	public List<Order> getAllActiveOrders() ;

}
