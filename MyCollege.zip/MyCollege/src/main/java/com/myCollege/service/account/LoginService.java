package com.myCollege.service.account;

import com.myCollege.actors.User;

public interface LoginService {

	public boolean validateUsername(String username, String password);

	public User getUser(String email);

	public boolean isAdmin(long phone);

	public boolean isAdmin(String email);
}
