package com.myCollege.service.adminImpl;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.myCollege.actors.Binding;
import com.myCollege.actors.Book;
import com.myCollege.actors.Category;
import com.myCollege.actors.Order;
import com.myCollege.form.BookForm;
import com.myCollege.service.admin.AdminService;
import com.myCollege.service.dao.AdminDao;

public class AdminServiceImpl implements AdminService{
	
	@Autowired
	private AdminDao adminDao;

	public void saveBooks(BookForm bookForm) {
		
		Iterator<Book> iterator = bookForm.getBooks().iterator();
		while(iterator.hasNext()){
			Book book = iterator.next();
			if(book.getISBN().isEmpty()){
				iterator.remove();
			}
			
			Iterator<Category> categoriesIterator = book.getCategories().iterator();
			while(categoriesIterator.hasNext()){
				Category category = categoriesIterator.next();
				if(category.getCategoryId() == null){
					categoriesIterator.remove();
				}
			}
		}
		
		
		adminDao.saveBooks(bookForm);
	}

	public boolean saveBinding(Binding binding) {
		return adminDao.saveBinding(binding);
	}

	public boolean saveCategory(Category category) {
		return adminDao.saveCategory(category);
	}

	public List<Order> getAllActiveOrders() {
		return adminDao.getAllActiveOrders();
	}

}
