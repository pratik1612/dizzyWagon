package com.myCollege.service.account;

import com.myCollege.actors.User;

public interface RegisterService {

	public void registerUser(User user);
}
