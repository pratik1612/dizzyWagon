package com.myCollege.service.dashboardImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.myCollege.actors.Address;
import com.myCollege.actors.Binding;
import com.myCollege.actors.Book;
import com.myCollege.actors.Category;
import com.myCollege.actors.Order;
import com.myCollege.dao.dashboard.SearchDao;
import com.myCollege.exceptions.SearchException;
import com.myCollege.service.dashboard.SearchService;

public class SearchServiceImpl implements SearchService {

	@Autowired
	private SearchDao searchDao;
	
	public List<Book> searchBooks(String searchString) throws SearchException  {
		return searchDao.searchBooks(searchString);
	}

	public Book searchBook(Integer bookId) {
		return searchDao.searchBook(bookId);
	}

	public List<Address> getAddressess(Integer userId) {
		return searchDao.getAddressess(userId);
	}

	public void saveAddress(Address address) {
		searchDao.saveAddress(address);
	}

	public Address getAddress(int addressId) {
		return searchDao.getAddress(addressId);
	}

	public void saveOrder(Order order) {
		searchDao.saveOrder(order);
	}

	public List<Binding> getAllBindings() {
		return searchDao.getAllBindings();
	}

	public List<Category> getAllCategories() {
		return searchDao.getAllCategories();
	}

	public List<Book> getBooksWithoutQuantities() {
		return searchDao.getBooksWithoutQuantities();
	}

}
