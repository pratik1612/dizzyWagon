package com.myCollege.service.accountImpl;

import org.springframework.beans.factory.annotation.Autowired;

import com.myCollege.actors.User;
import com.myCollege.dao.account.RegisterDao;
import com.myCollege.service.account.RegisterService;

public class RegisterServiceImpl implements RegisterService {

	@Autowired
	private RegisterDao userDao;
	public void registerUser(User user) {
		userDao.registerUser(user);
	}

}
