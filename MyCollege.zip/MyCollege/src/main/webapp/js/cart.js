$(document).ready(function() {

		 $('.alterCart').click(function(event) {
			var innerHtml = $(this).html();
			var quantity = $(this).siblings('.quantity').val();
			if(innerHtml===' + ' && quantity<4){
				 $(".loadingDivOuter").show();
				var bookId = $(this).attr("id").substr(13);
				var url = "${pageContext.request.contextPath}/increaseCart/"+bookId;	
				$(this).siblings('.quantity').val(quantity*1+1);
				$.ajax({
					url: url,
					type: 'get',
					dataType: 'json',
					success: function(book) {
						setTimeout(function () {
						    $(".loadingDivOuter").hide()
						}, 1000);
					},
					error:function(e){
						alert("error");
					}
			
			});
			}else if(innerHtml===' - ' && quantity>1){
				 $(".loadingDivOuter").show();
				var bookId = $(this).attr("id").substr(13);
				var url = "${pageContext.request.contextPath}/decreaseCart/"+bookId;	
				$(this).siblings('.quantity').val(quantity*1-1);
				$.ajax({
					url: url,
					type: 'get',
					dataType: 'json',
					success: function(book) {
						setTimeout(function () {
						    $(".loadingDivOuter").hide()
						}, 1000);
					},
					error:function(e){
						alert("error");
					}
			
			});
			}
		}); 
		 
		 $('.removeCart').click(function(event) {
			 $(".loadingDivOuter").show();
				var bookId = $(this).attr("id").substr(11);
				var url = "${pageContext.request.contextPath}/removeFromCart/"+bookId;	
				$.ajax({
					url: url,
					type: 'get',
					dataType: 'json',
					success: function(book) {
						var length = Object.keys(book.cart).length;
						$('.sc_items_total_new').text(length);
						$('#tr\\.'+bookId).remove();
						setTimeout(function () {
						    $(".loadingDivOuter").hide()
						}, 1000);
					},
					error:function(e){
						alert("error");
					}
			});
		 });
		 
	});
