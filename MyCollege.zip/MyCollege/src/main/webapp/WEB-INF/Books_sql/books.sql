insert into books values("","8126907622","R.D. Pradhan",160,75,"Atlantic","An Introduction To Operations Management",2017,1,1);
insert into books values("","8124803897","R J Maurya",320,975,"Springer","1965 War",2017,1,2);
insert into books values("","9386050722","Julie Sanders",1434,175,"Peacock","Antenna Theory",2011,2,3);
insert into books values("","8126921110","Arpita Basu roy",656,675,"Atlantic","Applied Ethics",2012,1,4);
insert into books values("","8182748860","Shaida Mohammad Abdali",444,395,"Atlantic","Applied Multivariate Statistics For The Social Sciences",2017,1,5);
insert into books values("","1138828998","Patrick Cockburn",400,375,"Springer","Architectural Design",2017,2,6);
insert into books values("","NOISBN0085","Mark V. Lawson",2323,715,"Peacock","As You Like It",2014,2,7);
insert into books values("","1119096855","Lewis Carroll",1233,1005,"Atlantic","Atlas Of An Anxious Man",2015,1,8);
insert into books values("","8124803749","Laksmi Pamuntjak",234,175,"Springer","Basic Algebraic Topology and its Applications",2017,1,9);
insert into books values("","8124803757","Klaus Hoffer",200,175,"Routledge","Boundary-Layer Theory",2013,2,10);
insert into books values("","8182748828","Ajay Das",120,175,"Peacock","Brand Management",2012,1,1);
insert into books values("","8182749034","Thomas A Birkland",2332,975,"Springer","C Programming With Solved Problems",2017,1,5);
insert into books values("","1784784494","Laksmi Pamuntjak",1290,385,"Routledge","Calculus Problems",2017,2,3);
insert into books values("","1482246473","Jill B. Delston",1160,345,"Springer","Centre Stage",2017,1,7);
insert into books values("","8124800901","Kumkum Sangari",1640,575,"Atlantic","China S Transition Under Xi Jinping",2017,1,10);


insert into subjects values("","Physics");
insert into subjects values("","Maths");
insert into subjects values("","History");
insert into subjects values("","English Literature");
insert into subjects values("","Microbiology");
insert into subjects values("","Genetics");
insert into subjects values("","Chemistry");
insert into subjects values("","Economics");
insert into subjects values("","Business Management");
insert into subjects values("","Politics and Current Affairs");


insert into binding values("","	");
insert into binding values("","Poor Binding");

